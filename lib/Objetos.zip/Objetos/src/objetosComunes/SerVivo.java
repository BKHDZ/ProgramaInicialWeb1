/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetosComunes;

/**
 *
 * @author FAMILIA
 */
public class SerVivo {
    private String tipo;
    private String nombre;
    private int edad;
    private int saud;
    private boolean vida;

    public SerVivo(String nombre, int edad) {
        this.tipo="Indeterminado";
        this.nombre = nombre;
        this.edad = edad;
        this.saud = 100;
        this.vida = true;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getSaud() {
        return saud;
    }

    public void setSaud(int saud) {
        this.saud = saud;
    }

    public boolean isVida() {
        return vida;
    }

    public void setVida(boolean vida) {
        this.vida = vida;
    }

    

}
