/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetosComunes;

import java.util.TreeMap;

/**
 *
 * @author FAMILIA
 */
public class Nave {

    public String nombre;
    public int integridadEstructural;
    public int tipulantesMaximos;
    public TreeMap<String, SerVivo> tripulantes;

    public Nave(String nombre, int tipulantesMaximos) {
        this.nombre = nombre;
        this.integridadEstructural = 100;
        this.tipulantesMaximos = tipulantesMaximos;
        this.tripulantes = new TreeMap<String, SerVivo>();
    }

    public boolean abordar(SerVivo serVivo) {
        if (this.tripulantes.size() < this.tipulantesMaximos) {
            this.tripulantes.put(serVivo.getNombre(), serVivo);
            return true;
        } else {
            return false;
        }
    }

    public boolean avadonarNave(String nombreDePersona) {
        if (this.tripulantes.containsKey(nombreDePersona)) {
            this.tripulantes.remove(nombreDePersona);
            return true;
        } else {
            return false;
        }
    }

    public int getIntegridadEstructural() {
        return integridadEstructural;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public TreeMap<String, SerVivo> getTripulantes() {
        return tripulantes;
    }
    
    

}
