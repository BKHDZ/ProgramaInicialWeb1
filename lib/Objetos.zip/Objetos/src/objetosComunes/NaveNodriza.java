/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetosComunes;

import java.util.Map;
import java.util.TreeMap;

/**
 *
 * @author FAMILIA
 */
public class NaveNodriza extends Nave {

    private int maximoDeNavesDeEscape;
    private TreeMap<String, NaveEscape> puertosDeNavesDeEscape;

    public NaveNodriza(String nombre) {
        super(nombre, 1000);
        this.maximoDeNavesDeEscape = 100;
        this.puertosDeNavesDeEscape = new TreeMap<String, NaveEscape>();
        for (int i = 0; i < 5; i++) {
            NaveEscape naveEscape = new NaveEscape(nombre + "-" + i);
            this.puertosDeNavesDeEscape.put(naveEscape.getNombre(), naveEscape);
        }

    }

//    public void listaLasNavesDeEscape() {
//        for (Map.Entry<String, NaveEscape> entry : this.puertosDeNavesDeEscape.entrySet()) {
//            NaveEscape naveEscape = entry.getValue();
//            System.out.println(naveEscape.getNombre());
//        }
//    }

    public boolean enviaNaveDeEscape(NaveNodriza naveNodrizaObjetivo, String nombreDeNaveDeEscape) {
        if (this.puertosDeNavesDeEscape.containsKey(nombreDeNaveDeEscape)) {
            NaveEscape naveEscape = this.puertosDeNavesDeEscape.get(nombreDeNaveDeEscape);
            boolean puedeRecibirla = naveNodrizaObjetivo.recibeNaveDeEscape(naveEscape);
            if (puedeRecibirla) {
                this.puertosDeNavesDeEscape.remove(nombreDeNaveDeEscape);
                return true;
            } else {
                return false;
            }

        } else {
            return false;
        }
    }

    public boolean recibeNaveDeEscape(NaveEscape naveEscape) {
        if (this.puertosDeNavesDeEscape.size() < maximoDeNavesDeEscape) {
            this.puertosDeNavesDeEscape.put(naveEscape.getNombre(), naveEscape);
            return true;
        } else {
            return false;
        }
    }
    
   public void listaTripulantes(){
       for (Map.Entry<String, SerVivo> entry : tripulantes.entrySet()) {
           SerVivo tripulante = entry.getValue();
           System.out.println("Nave:"+this.getNombre()+" Tripulante:"+tripulante.getNombre()+" Tipo: "+tripulante.getTipo());
       }
       for (Map.Entry<String, NaveEscape> entry : puertosDeNavesDeEscape.entrySet()) {
           NaveEscape naveEscape = entry.getValue();
           TreeMap<String,SerVivo>trupulantes=naveEscape.getTripulantes();
           for (Map.Entry<String, SerVivo> entry1 : trupulantes.entrySet()) {
               SerVivo tripulante = entry1.getValue();
               System.out.println("Nave:"+this.getNombre()+"/NaveEscape:"+naveEscape.getNombre()+" Tripulante:"+tripulante.getNombre()+" Tipo: "+tripulante.getTipo());
           }
       }
       
       
   }
    
    
    
    
    

//    public NaveEscape getNaveDeEscape(String nombreDeNaveDeEscape) {
//        return this.puertosDeNavesDeEscape.get(nombreDeNaveDeEscape);
//    }
}
